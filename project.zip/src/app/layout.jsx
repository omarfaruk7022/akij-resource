// src/app/layout.jsx
import Navbar from "@/components/shared/Navbar";
import "./globals.css";
import Providers from "@/components/shared/Providers";
import Footer from "@/components/shared/Footer";

export const metadata = {
  title: "AssessHub – Online Assessment Platform",
  description:
    "Professional online assessment platform for employers and candidates",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="h-full">
      <body className="min-h-full antialiased bg-gray-50 font-sans">
        <Providers>
          <Navbar />
          {children}
          <Footer />
        </Providers>
      </body>
    </html>
  );
}
