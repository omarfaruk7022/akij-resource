"use client";
// src/app/employer/layout.jsx
import { useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import Navbar from "@/components/shared/Navbar";
import Footer from "@/components/shared/Footer";
import ToastContainer from "@/components/ui/Toast";
import useAuthStore from "@/store/useAuthStore";

function getPageLabel(pathname) {
  if (pathname.includes("/create-exam")) return "Online Test";
  if (pathname.includes("/candidates")) return "Candidates";
  if (pathname.includes("/exams")) return "Exams";
  return "Dashboard";
}

export default function EmployerLayout({ children }) {
  const { user, token } = useAuthStore();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (!token) {
      router.replace("/login");
      return;
    }
    if (user && user.role !== "employer")
      router.replace("/candidate/dashboard");
  }, [token, user, router]);

  if (!user || user.role !== "employer") {
    return (
      <>
        <ToastContainer />
        {children}
      </>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-[#F5F5F5]">
      {/* <Navbar activePage={getPageLabel(pathname)} /> */}
      <main className="flex-1 overflow-y-auto">{children}</main>
      {/* <Footer /> */}
      <ToastContainer />
    </div>
  );
}
