'use client';
// src/app/candidate/layout.jsx
import { useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import CandidateSidebar from '@/components/shared/CandidateSidebar';
import ToastContainer from '@/components/ui/Toast';
import useAuthStore from '@/store/useAuthStore';

export default function CandidateLayout({ children }) {
  const { user, token } = useAuthStore();
  const router = useRouter();
  const pathname = usePathname();

  const isExamPage = pathname?.includes('/candidate/exam/');
  const isLoginPage = pathname === '/login';

  useEffect(() => {
    if (!isLoginPage && !token) {
      router.replace('/login');
      return;
    }
    if (token && user && user.role !== 'candidate' && !isLoginPage) {
      router.replace('/employer/dashboard');
    }
  }, [token, user, router, isLoginPage]);

  // Exam page gets no sidebar (fullscreen mode)
  if (isExamPage) {
    return (
      <>
        <ToastContainer />
        {children}
      </>
    );
  }

  if (isLoginPage || !user || user.role !== 'candidate') {
    return (
      <>
        <ToastContainer />
        {children}
      </>
    );
  }

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      <CandidateSidebar />
      <div className="flex-1 ml-64 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-y-auto">{children}</main>
      </div>
      <ToastContainer />
    </div>
  );
}
